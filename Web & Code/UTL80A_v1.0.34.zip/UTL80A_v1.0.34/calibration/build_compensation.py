"""Infer effective coil projections and fit gain-preserving lateral compensation.

All inference is offline. Firmware uses the resulting linear matrix only.
"""
from pathlib import Path
import csv
import itertools
import json

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
AXES=('Fx','Fy','Fz','Tx','Ty','Tz')
PAIR=((4,5),(2,3),(0,1),(6,7))
SCALE=10000.


def load():
    with (HERE/'training_and_holdout_v1.0.32.csv').open(encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    x=np.array([[float(r[f'Delta_L{i}']) for i in range(1,9)] for r in rows])/SCALE
    y=np.array([[float(r['Reference_'+a]) for a in AXES] for r in rows])
    with (HERE/'matrix_coefficients_v1.0.33.csv').open(encoding='utf-8-sig') as f:
        prior=np.array([[float(r[f'L{i}']) for i in range(1,9)] for r in csv.DictReader(f)])*SCALE
    source=json.loads((HERE/'simulation_compliance_v1.0.34.json').read_text(encoding='utf-8'))
    return rows,x,y,prior,np.array(source['displacement_per_unit_load']),source


def weights(rows):
    categories=[r['category'] for r in rows]
    counts={c:categories.count(c) for c in set(categories)}
    return np.array([1/counts[c] for c in categories])


def transform(sim,config):
    perm=[1,0,2,3,4,5] if config['swap_force'] else list(range(6))
    if config['swap_torque']: perm[3:5]=[4,3]
    sim=sim[perm].copy()
    for a,sign in zip((2,3,4),config['signs']): sim[a]*=sign
    order=[i for pair,flip in zip(PAIR,config['flips']) for i in (pair[::-1] if flip else pair)]
    return sim[:,order,:]


def projection(rows,x,y,sim,planes):
    w=weights(rows)/np.maximum(np.linalg.norm(x,axis=1),.05)**2
    gains=[]
    for i in range(8):
        dims=[1 if i in (0,1,4,5) else 0,2] if planes==2 else [0,1,2]
        a=(y@sim[:,i,:])[:,dims]
        g=np.linalg.lstsq(a*np.sqrt(w[:,None]),x[:,i]*np.sqrt(w),rcond=None)[0]
        full=np.zeros(3);full[dims]=g;gains.append(full)
    gains=np.array(gains)
    k=np.einsum('aci,ci->ca',sim,gains)
    err=float(np.sum(w[:,None]*(y@k.T-x)**2)/weights(rows).sum())
    return gains,k,err


def choose_geometry(rows,x,y,sim):
    candidates=[]
    for sf,st in itertools.product((False,True),repeat=2):
      for signs in itertools.product((-1,1),repeat=3):
       for flips in itertools.product((False,True),repeat=4):
        for planes in (2,3):
         config=dict(swap_force=sf,swap_torque=st,signs=signs,flips=flips,planes=planes)
         _,_,error=projection(rows,x,y,transform(sim,config),planes)
         candidates.append(dict(config=config,training_relative_mse=error))
    candidates.sort(key=lambda item:item['training_relative_mse'])
    finalists=candidates[:32]
    labels=np.array([r['repeat'] for r in rows])
    for item in finalists:
        prediction=np.zeros_like(x)
        mapped=transform(sim,item['config'])
        for group in np.unique(labels):
            mask=labels==group
            train=[r for r,keep in zip(rows,~mask) if keep]
            _,k,_=projection(train,x[~mask],y[~mask],mapped,item['config']['planes'])
            prediction[mask]=y[mask]@k.T
        w=weights(rows)/np.maximum(np.linalg.norm(x,axis=1),.05)**2
        item['repeat_relative_mse']=float(np.sum(w[:,None]*(prediction-x)**2)/weights(rows).sum())
    finalists.sort(key=lambda item:item['repeat_relative_mse'])
    return finalists


def fit(rows,x,y,prior,sim,config,regularization,tz_anchor):
    cat=np.array([r['category'] for r in rows])
    xy=(y[:,0]!=0)|(y[:,1]!=0)
    axial=cat=='Fz';txy=(y[:,3]!=0)|(y[:,4]!=0)
    gains,k,_=projection(rows,x,y,transform(sim,config),config['planes'])
    # Preserve actual mean per-load lateral response, including cross-axis
    # response, instead of merely rewarding near-zero output on all samples.
    force=np.column_stack([np.mean(x[y[:,a]!=0]/y[y[:,a]!=0,a,None],axis=0) for a in (0,1)])
    axial_direction=np.mean(x[axial]/(-y[axial,2,None]),axis=0)
    axial_direction/=np.linalg.norm(axial_direction)
    q=np.column_stack([k[:,a]/np.linalg.norm(k[:,a]) for a in (3,4)])
    constraints=np.column_stack([axial_direction,force])
    p=prior[:2].T
    target=x@p;target[axial|txy]=0
    w=weights(rows)*np.where(xy,4.,np.where(cat=='Tz+',tz_anchor,1.))
    gram=x.T@(w[:,None]*x)+regularization*np.eye(8)+.1*q@q.T
    rhs=x.T@(w[:,None]*target)+regularization*p
    values=np.vstack([np.zeros((1,2)),force.T@p])
    kkt=np.block([[gram,constraints],[constraints.T,np.zeros((3,3))]])
    solved=np.linalg.solve(kkt,np.vstack([rhs,values]))[:8].T
    return solved,gains,k


def masks(y,rows):
    return dict(Fxy=(y[:,0]!=0)|(y[:,1]!=0),Txy=(y[:,3]!=0)|(y[:,4]!=0),
                Fz=np.array([r['category']=='Fz' for r in rows]),
                Tz=np.array([r['category']=='Tz+' for r in rows]))


def metrics(pred,y,rows):
    result={group:np.sqrt(np.mean((pred[mask]-y[mask,:2])**2,axis=0)).tolist()
            for group,mask in masks(y,rows).items() if np.any(mask)}
    if 'Fxy' in result:
        result['mean_main_gain']=[float(np.mean(pred[y[:,a]!=0,a]/y[y[:,a]!=0,a])) for a in (0,1)]
    return result


def validation(rows,x,y,prior,sim,config,reg,tz_anchor,split):
    labels=np.array([r[split] for r in rows])
    if split=='session': groups=sorted({r['session'] for r in rows if r['category']=='Fz'})
    else: groups=np.unique(labels)
    prediction=np.full((len(x),2),np.nan)
    for group in groups:
        selected=labels==group
        train=[r for r,keep in zip(rows,~selected) if keep]
        c,_,_=fit(train,x[~selected],y[~selected],prior,sim,config,reg,tz_anchor)
        prediction[selected]=x[selected]@c.T
    return prediction


def main():
    rows,x,y,prior,sim,source=load()
    finalists=choose_geometry(rows,x,y,sim)
    config=finalists[0]['config']
    old=x@prior[:2].T
    baseline=metrics(old,y,rows)
    options=[]
    for reg,tz_anchor in itertools.product((.01,.1,1.),(.1,1.,4.)):
        held=validation(rows,x,y,prior,sim,config,reg,tz_anchor,'repeat')
        for blend in (1.,.75,.5,.25,.125,0.):
            pred=old+blend*(held-old)
            report=metrics(pred,y,rows)
            # Bound regressions on other tested cases while selecting on Txy.
            feasible=all(report[group][a]<=baseline[group][a]*bound+1e-10
                         for group,bound in (('Fxy',1.02),('Fz',1.10),('Tz',1.05)) for a in (0,1))
            feasible &= all(report['mean_main_gain'][a]>=baseline['mean_main_gain'][a]*.98 for a in (0,1))
            score=sum(report['Txy'][a]/baseline['Txy'][a] for a in (0,1))
            options.append(dict(regularization=reg,tz_anchor=tz_anchor,blend=blend,
                                feasible=bool(feasible),score=score,repeat=report))
    selected=min((item for item in options if item['feasible']),key=lambda item:item['score'])
    reg,tz_anchor,blend=(selected[k] for k in ('regularization','tz_anchor','blend'))
    c,gains,forward=fit(rows,x,y,prior,sim,config,reg,tz_anchor)
    result=prior.copy();result[:2]=prior[:2]+blend*(c-prior[:2])
    tilt=np.degrees(np.arctan2(np.linalg.norm(gains[:,:2],axis=1),abs(gains[:,2])))
    folds=[]
    labels=np.array([r['repeat'] for r in rows])
    for group in np.unique(labels):
        keep=labels!=group;train=[r for r,k in zip(rows,keep) if k]
        _,g,_=fit(train,x[keep],y[keep],prior,sim,config,reg,tz_anchor)
        folds.append(np.degrees(np.arctan2(np.linalg.norm(g[:,:2],axis=1),abs(g[:,2]))))
    checks={}
    for split in ('repeat','level','session'):
        held=validation(rows,x,y,prior,sim,config,reg,tz_anchor,split)
        valid=np.isfinite(held).all(axis=1)
        rr=[r for r,k in zip(rows,valid) if k]
        checks[split]=dict(old=metrics(old[valid],y[valid],rr),
                           new=metrics((old+blend*(held-old))[valid],y[valid],rr))
    coefficient=result/SCALE
    report=dict(version='v1.0.34',source=source,geometry_candidates=1024,
                geometry_finalists=finalists,selected_compensation=selected,
                selection_comparisons=options,coefficients=coefficient.tolist(),
                effective_projection=gains.tolist(),effective_tilt_from_Z_deg=tilt.tolist(),
                fixed_configuration_fold_tilt_range_deg=[np.min(folds,axis=0).tolist(),np.max(folds,axis=0).tolist()],
                geometry_forward_counts_per_load=(forward*SCALE).tolist(),
                fitted=dict(old=baseline,new=metrics(x@result[:2].T,y,rows)),validation=checks,
                qualification='Effective projection estimates are not measured installation angles. Geometry configuration and compensation selected on the existing data; baseline v1.0.33 already used these records. Internal comparisons are not independent acceptance. Only Fx/Fy rows change; their low baseline mean gains are preserved, not corrected.')
    report_path=ROOT/'reports/compensation_v1.0.34.json'
    report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    header=ROOT/'arduino/UTL80A_v1.0.34/utl80a_calibration_lab.h'
    text=header.read_text(encoding='utf-8')
    start=text.index('{\n',text.index('static const float UTL80A_C'))+2
    stop=text.index('\n};',start);lines=text[start:stop].splitlines()
    for i in range(2): lines[i]='    {'+', '.join(f'{v:.10e}f' for v in coefficient[i])+'},'
    header.write_text(text[:start]+'\n'.join(lines)+text[stop:],encoding='utf-8')
    with (ROOT/'reports/matrix_coefficients_v1.0.34.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['axis']+[f'L{i}' for i in range(1,9)])
        writer.writerows([[a,*row] for a,row in zip(AXES,coefficient)])
    print(json.dumps(dict(selected=selected,angles=tilt.tolist(),validation=checks),indent=2))


if __name__=='__main__': main()
