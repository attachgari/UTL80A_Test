/* UTL80A v1.0.30. Current axes with Fz refit from screened TestData_1123 steps. */
#ifndef UTL80A_CALIBRATION_LAB_H
#define UTL80A_CALIBRATION_LAB_H
#include <stdint.h>
#define UTL80A_OUTPUT_COUNT 6
#define UTL80A_TZ_NEG_GAIN 1.20f
static const char *const UTL80A_OUTPUT_AXES[UTL80A_OUTPUT_COUNT] = {"Fx", "Fy", "Fz", "Tx", "Ty", "Tz"};
static const float UTL80A_C[UTL80A_OUTPUT_COUNT][8] = {
    {3.0940981989e-03f, -4.6049408991e-03f, 8.7407141451e-04f, 5.0636321286e-04f, 1.7983287290e-03f, -2.2109188030e-03f, 1.1440532412e-03f, -6.0105509442e-04f},
    {3.7556731564e-03f, -3.4264963888e-03f, 7.1033462864e-04f, -5.1152597610e-04f, -1.4621051972e-03f, 1.7158181651e-03f, -8.1487236525e-04f, 3.3173977218e-05f},
    {1.2781184380e-03f, -1.3566677992e-03f, 1.1161647137e-03f, -1.0361769043e-03f, -9.3304428568e-04f, 9.3999780437e-04f, -1.0850416591e-03f, 1.1395464268e-03f},
    {-6.6059492710e-05f, 1.0812048752e-04f, -9.7393377322e-06f, -2.7344332752e-06f, -5.6326568977e-05f, 2.8258145049e-05f, -9.2120043462e-06f, 7.6932044702e-06f},
    {-8.9938682198e-05f, 8.2509174138e-05f, 3.1263782605e-06f, 2.3786094447e-05f, -5.8733776759e-06f, -1.3010443912e-05f, 2.6679982231e-06f, -3.2671412821e-06f},
    {-3.0219055225e-05f, 3.0219055225e-05f, -2.5433573511e-05f, 2.5433573511e-05f, -2.1733505205e-05f, 2.1733505205e-05f, -3.2249209148e-05f, 3.2249209148e-05f}
};
static inline void utl80a_predict_delta(const float delta[8], float wrench[UTL80A_OUTPUT_COUNT]) {
    for (unsigned a = 0; a < UTL80A_OUTPUT_COUNT; ++a) {
        float value = 0.0f;
        for (unsigned ch = 0; ch < 8; ++ch) value += UTL80A_C[a][ch] * delta[ch];
        wrench[a] = value;
    }
    if (wrench[5] < 0.0f) wrench[5] *= UTL80A_TZ_NEG_GAIN;
}
/* tare_raw must be the local mean under the intended unloaded fixture condition. */
static inline void utl80a_predict(const uint32_t raw[8], const double tare_raw[8],
                                  float wrench[UTL80A_OUTPUT_COUNT]) {
    float delta[8];
    for (unsigned ch = 0; ch < 8; ++ch) delta[ch] = (float)((double)raw[ch] - tare_raw[ch]);
    utl80a_predict_delta(delta, wrench);
}
#endif