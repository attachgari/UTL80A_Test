"""Audit TestData_1123 and fit an odd, zero-intercept Fz model."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from openpyxl import load_workbook

RELEASE = Path(__file__).resolve().parents[1]
G = 9.80665
TEMP_COEFFICIENT = 10.45  # Current firmware value, treated as fixed during this Fz refit.


def columns(sheet):
    iterator = iter(sheet.values)
    names = next(iterator)
    records = list(iterator)
    index = {name: i for i, name in enumerate(names)}
    raw = np.array([[row[index[f"L{i}"]] for i in range(1, 9)] for row in records], dtype=float)
    temp = np.array([[row[index[f"TMP117_{i}"]] for i in range(1, 5)] for row in records], dtype=float)
    t = np.array([row[index["Elapsed_Time"]] for row in records], dtype=float)
    repeat = np.array([row[index["Repeat"]] for row in records], dtype=int)
    state = np.array([row[index["State"]] for row in records])
    mass = np.array([row[index["Applied_Load"]] for row in records], dtype=float)
    valid = (np.isfinite(raw).all(1) & (raw > 0).all(1) & (raw < (1 << 28) - 1).all(1)
             & np.isfinite(temp).all(1) & (temp != 0).all(1) & np.isfinite(t))
    return t, raw, temp.mean(1), repeat, state, mass, valid


def read_steps(data):
    trials = []
    for path in sorted((data / "261123_Fz_5s").rglob("*.xlsx")):
        book = load_workbook(path, read_only=True, data_only=True)
        for sheet in book:
            t, raw, temp, repeat, state, mass, valid = columns(sheet)
            for number in np.unique(repeat):
                u = valid & (repeat == number) & (state == "Unloaded")
                l = valid & (repeat == number) & (state == "Loaded")
                if not u.any() or not l.any():
                    raise ValueError(f"Unpaired trial {path}, {sheet.title}, {number}")
                baseline = u & (t >= t[u][-1] - 2)
                tail = l & (t >= t[l][-1] - 2)
                delta = raw[l] - raw[baseline].mean(0)
                time = t[l] - t[l][0]
                buckets = np.floor(time).astype(int)
                curve = np.array([delta[buckets == i].mean(0) for i in np.unique(buckets)])
                late = curve[1:]
                common = curve.sum(1)
                mean_delta = raw[tail].mean(0) - raw[baseline].mean(0)
                trial = dict(source=path.relative_to(data).as_posix(), sheet=sheet.title,
                             session=path.parent.name, repeat=int(number), mass_kg=float(mass[l][0]),
                             source_first_row=int(np.flatnonzero(repeat == number)[0] + 2),
                             source_last_row=int(np.flatnonzero(repeat == number)[-1] + 2),
                             invalid_rows=int(((repeat == number) & ~valid).sum()),
                             samples=int(l.sum()), reference_N=-float(mass[l][0])*G,
                             delta=mean_delta, curve=curve, t=time, trace=delta.sum(1),
                             dtemp=float(temp[tail].mean() - temp[baseline].mean()),
                             sum_delta=float(mean_delta.sum()), reason=[])
                magnitude = abs(trial["sum_delta"])
                if magnitude < 1:
                    trial["reason"].append("no_load_response")
                if trial["sum_delta"] <= 0:
                    trial["reason"].append("opposite_response")
                if len(late) and np.ptp(late.sum(1)) > .15 * max(magnitude, 1):
                    trial["reason"].append("loaded_curve_changes_over_15_percent_after_first_second")
                if np.max(np.abs(np.diff(common))) > .20 * max(magnitude, 1):
                    trial["reason"].append("one_second_jump_over_20_percent")
                if np.unique(raw[l], axis=0).shape[0] < 5:
                    trial["reason"].append("stale_raw")
                trials.append(trial)
        book.close()
    for mass in sorted({trial["mass_kg"] for trial in trials}):
        same = [trial for trial in trials if trial["mass_kg"] == mass and not trial["reason"]]
        values = np.array([trial["sum_delta"] for trial in same])
        median = np.median(values)
        spread = max(1.4826*np.median(abs(values-median)), .03*abs(median))
        for trial in same:
            trial["same_load_median_counts"] = float(median)
            trial["same_load_robust_z"] = float((trial["sum_delta"] - median)/spread)
            if abs(trial["sum_delta"] - median) > 4*spread:
                trial["reason"].append("same_load_amplitude_beyond_4_MAD_sigma")
    return trials


def read_holds(data):
    path = data / "261120_Fz300s" / "UTL80A_TxyFz_300s_Data.xlsx"
    book = load_workbook(path, read_only=True, data_only=True)
    sessions = []
    for sheet in book:
        t, raw, temp, _, _, mass, valid = columns(sheet)
        cuts = np.r_[0, np.flatnonzero(np.diff(t) < -.1) + 1, len(t)]
        for number, (start, end) in enumerate(zip(cuts, cuts[1:]), 1):
            mask = valid[start:end]
            tt = t[start:end][mask]
            r = raw[start:end][mask]
            te = temp[start:end][mask]
            tt -= tt[0]
            sec = np.floor(tt).astype(int)
            grid = np.unique(sec)
            per_second = np.array([r[sec == j].mean(0) for j in grid])
            temp_seconds = np.array([te[sec == j].mean() for j in grid])
            reason = []
            if np.unique(r, axis=0).shape[0] < 5:
                reason.append("stale_raw")
            if tt[-1] < 60:
                reason.append("recording_shorter_than_60_seconds")
            drift = float(np.ptp(per_second.sum(1)))
            if drift > 10000:
                reason.append("hold_common_mode_drift_over_10000_counts")
            sessions.append(dict(sheet=sheet.title, recording=number, duration_s=float(tt[-1]),
                                 source_first_row=int(start+2), source_last_row=int(end+1),
                                 mass_kg=float(mass[start]), invalid_rows=int((~mask).sum()),
                                 sum_range_counts=drift, t=grid, raw=per_second, temp=temp_seconds,
                                 reason=reason))
    book.close()
    return sessions


def features(x, method):
    if method == "common":
        return x.sum(1, keepdims=True) / 100000
    if method == "pairs":
        return x.reshape(len(x), 4, 2).sum(2) / 25000
    return x / 12500


def fit(x, y, strength):
    prior = np.full(x.shape[1], -14.7 / x.shape[1])
    return np.linalg.solve(x.T @ x / len(x) + strength*np.eye(x.shape[1]),
                           x.T @ y / len(x) + strength*prior)


def rmse(x):
    return float(np.sqrt(np.mean(np.square(x))))


def compare(trials):
    good = [t for t in trials if not t["reason"]]
    raw = np.array([t["delta"] for t in good])
    target = np.array([t["reference_N"] + TEMP_COEFFICIENT*t["dtemp"] for t in good])
    results = {}
    for method in ("common", "pairs", "eight"):
        x = features(raw, method)
        for strength in ([0.] if method == "common" else [.00001, .00003, .0001, .001, .01, .1, 1.]):
            key = f"{method}_{strength:g}"
            result = {}
            for split in ("session", "mass_kg", "repeat"):
                labels = np.array([t[split] for t in good])
                pred = np.zeros(len(target))
                for label in np.unique(labels):
                    test = labels == label
                    pred[test] = x[test] @ fit(x[~test], target[~test], strength)
                result[split] = dict(rmse_N=rmse(pred-target), max_error_N=float(abs(pred-target).max()),
                                     predictions_N=pred.tolist())
            result["score"] = max(result[v]["rmse_N"] for v in ("session", "mass_kg"))
            result["coefficients"] = fit(x, target, strength).tolist()
            results[key] = result
    return good, results


def plot(trials, holds, destination):
    fig, axes = plt.subplots(2, 2, figsize=(12, 7))
    for axis, mass in zip(axes.flat, sorted({t["mass_kg"] for t in trials})):
        for t in trials:
            if t["mass_kg"] != mass:
                continue
            axis.plot(t["t"], t["trace"]/1000, color="tomato" if t["reason"] else "steelblue",
                      alpha=.7, linewidth=1, label=f'{t["session"]}/{t["repeat"]}' if t["reason"] else None)
        axis.set(title=f"Fz {mass:g} kg", xlabel="Loaded time (s)", ylabel="Sum of RAW deltas (kcounts)")
        handles, labels = axis.get_legend_handles_labels()
        if handles:
            axis.legend(fontsize=7)
        axis.grid(alpha=.2)
    fig.suptitle("All measured repeats: blue retained, red excluded")
    fig.tight_layout()
    fig.savefig(destination / "Fz_repeat_audit_v1.0.30.png", dpi=160)
    plt.close(fig)
    fig, axes = plt.subplots(3, 3, figsize=(13, 9))
    for ax, hold in zip(axes.flat, holds):
        s = hold["raw"].sum(1)
        ax.plot(hold["t"], (s-s[0])/1000)
        ax.set(title=f'{hold["sheet"]} recording {hold["recording"]}', xlabel="Time (s)",
               ylabel="Common-mode change (kcounts)")
        ax.grid(alpha=.2)
    for ax in axes.flat[len(holds):]:
        ax.set_visible(False)
    fig.tight_layout()
    fig.savefig(destination / "Fz_hold_audit_v1.0.30.png", dpi=150)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    args = parser.parse_args()
    destination = RELEASE / "reports"
    destination.mkdir(exist_ok=True)
    trials = read_steps(args.data_dir)
    holds = read_holds(args.data_dir)
    good, results = compare(trials)
    selected = min(results, key=lambda name: results[name]["score"])
    model = results[selected]
    method = selected.split("_")[0]
    reduced = np.array(model["coefficients"])
    if method == "common":
        coefficients = np.repeat(reduced[0]/100000, 8)
    elif method == "pairs":
        coefficients = np.repeat(reduced/25000, 2)
    else:
        coefficients = reduced/12500
    print("TRIALS", len(trials), "RETAINED", len(good))
    for t in trials:
        if t["reason"]:
            print("EXCLUDE", t["session"], t["sheet"], t["repeat"], round(t["sum_delta"]), t["reason"])
    for name, metrics in results.items():
        print(name, "LO-session / LO-load / LO-repeat",
              [round(metrics[k]["rmse_N"], 4) for k in ("session", "mass_kg", "repeat")])
    measured = np.array([t["reference_N"] for t in good])
    thermal = TEMP_COEFFICIENT*np.array([t["dtemp"] for t in good])
    prediction = np.array([t["delta"] for t in good]) @ coefficients - thermal
    before = np.array([-.0002632*t["sum_delta"] for t in good]) - thermal
    summary = dict(reference="Fz compression = -mass_kg * 9.80665 N; Fz+ mirrored about tare",
                   sources=[dict(file=path.relative_to(args.data_dir).as_posix(),
                                 sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                            for path in sorted(args.data_dir.rglob("*.xlsx"))],
                   original_trials=len(trials), retained_trials=len(good),
                   selected_model=selected, coefficients_N_per_count=coefficients.tolist(),
                   fixed_temperature_coefficient_N_per_C=TEMP_COEFFICIENT,
                   temperature_qualification="Inherited from Current; the new zero-load holds were stale or unstable. Not independently refitted here.",
                   validation_qualification="Internal model comparison after fixed data screening. Hyperparameter selection uses the reported folds. Independent positive Fz and fresh session validation remain required.",
                   old_retained_rmse_N=rmse(before-measured),
                   fitted_retained_rmse_N=rmse(prediction-measured),
                   fitted_retained_max_error_N=float(abs(prediction-measured).max()),
                   per_load=[dict(mass_kg=mass, repeats=int(sum(t["mass_kg"] == mass for t in good)),
                                  reference_N=-mass*G,
                                  prediction_mean_N=float(prediction[[t["mass_kg"] == mass for t in good]].mean()))
                             for mass in sorted({t["mass_kg"] for t in good})],
                   models=results,
                   hold_audit=[{k:v for k,v in h.items() if k not in ("raw", "temp", "t")} for h in holds])
    (destination / "Fz_validation_v1.0.30.json").write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8")
    print("SELECTED", selected, "N/count", coefficients.tolist())
    print("Retained old / fitted RMSE", summary["old_retained_rmse_N"], summary["fitted_retained_rmse_N"])
    header_path = RELEASE / "arduino" / "UTL80A_v1.0.30" / "utl80a_calibration_lab.h"
    original = header_path.read_text(encoding="utf-8")
    start = original.index("static const float UTL80A_C")
    rows_start = original.index("{\n", start) + 2
    matrix_end = original.index("\n};", rows_start)
    matrix_rows = original[rows_start:matrix_end].splitlines()
    assert len(matrix_rows) == 6
    matrix_rows[2] = "    {" + ", ".join(f"{value:.10e}f" for value in coefficients) + "},"
    generated = original[:rows_start]+"\n".join(matrix_rows)+original[matrix_end:]
    first_line = generated.index("\n")
    generated = "/* UTL80A v1.0.30. Current axes with Fz refit from screened TestData_1123 steps. */" + generated[first_line:]
    header_path.write_text(generated, encoding="utf-8")
    rows = []
    for t in trials:
        row = {k:v for k,v in t.items() if k not in ("delta", "curve", "t", "trace", "reason")}
        row.update(accepted=not t["reason"], reason=" | ".join(t["reason"]),
                   old_prediction_N=float(-.0002632*t["sum_delta"]-TEMP_COEFFICIENT*t["dtemp"]),
                   new_prediction_N=float(t["delta"]@coefficients-TEMP_COEFFICIENT*t["dtemp"]),
                   **{f"Delta_L{i+1}":float(v) for i,v in enumerate(t["delta"])})
        rows.append(row)
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with (destination/"Fz_trial_audit_v1.0.30.csv").open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    plot(trials, holds, destination)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].scatter(-measured, -before, label="Current", alpha=.6)
    axes[0].scatter(-measured, -prediction, label="v1.0.30 fitted", alpha=.6)
    axes[0].plot([0, 21], [0, 21], "k--", linewidth=1)
    axes[0].set(xlabel="Reference compression magnitude (N)", ylabel="Prediction magnitude (N)")
    axes[0].legend()
    for split, label in (("session", "Held session"), ("mass_kg", "Held load level")):
        errors = np.array(model[split]["predictions_N"]) - measured - thermal
        axes[1].scatter(-measured, errors, label=label, alpha=.6)
    axes[1].axhline(0, color="black", linewidth=1)
    axes[1].set(xlabel="Reference compression magnitude (N)", ylabel="Internal validation error (N)")
    axes[1].legend()
    for ax in axes:
        ax.grid(alpha=.2)
    fig.tight_layout()
    fig.savefig(destination/"Fz_calibration_v1.0.30.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()
